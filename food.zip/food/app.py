from flask import Flask, render_template, request, redirect, url_for, flash, session
import pymysql
import os
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
import requests
import json
from datetime import datetime, timedelta
import re

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # 请更改为安全的密钥

# 数据库配置
DB_CONFIG = {
    'host': '106.14.246.124',
    'port': 3306,
    'user': 'studyuser',
    'password': '123456',
    'database': 'food'
}

# 阿里云百炼API配置（请替换为您的实际配置）
ALIYUN_API_KEY = 'sk-ab18fb0111c348d9bd6e3d97c888afba'
ALIYUN_API_URL = 'https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation'

# 上传文件夹
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def clean_text(text):
    # 去除 Markdown 格式符号
    text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)  # 去除粗体 **
    text = re.sub(r'\*(.*?)\*', r'\1', text)      # 去除斜体 *
    text = re.sub(r'^#+\s*', '', text, flags=re.MULTILINE)  # 去除标题 #
    text = re.sub(r'^[-\*]\s*', '', text, flags=re.MULTILINE)  # 去除列表符号
    text = re.sub(r'\n+', ' ', text)  # 将多行换行替换为单个空格
    return text.strip()

def parse_date(date_str):
    today = datetime.now().date()
    try:
        parsed_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        return parsed_date if parsed_date <= today else today
    except Exception:
        return today

def get_day_of_week(date_obj):
    weekdays = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日']
    return weekdays[date_obj.weekday()]

def get_db_connection():
    return pymysql.connect(**DB_CONFIG)

def calculate_calories_with_ai(food_name, weight):
    # 使用阿里云百炼大模型计算卡路里
    prompt = f"请根据食物名称'{food_name}'和重量{weight}克，估算该食物的卡路里含量。只返回数字，单位为千卡。"
    
    headers = {
        'Authorization': f'Bearer {ALIYUN_API_KEY}',
        'Content-Type': 'application/json'
    }
    
    data = {
        'model': 'qwen-turbo',  # 或其他可用模型
        'input': {
            'messages': [
                {'role': 'user', 'content': prompt}
            ]
        }
    }
    
    try:
        response = requests.post(ALIYUN_API_URL, headers=headers, json=data)
        result = response.json()
        calories = float(result['output']['text'].strip())
        return calories
    except Exception as e:
        print(f"AI计算卡路里失败: {e}")
        return 0  # 默认值

def get_exercise_suggestion(total_calories):
    # 使用AI生成运动建议
    prompt = f"用户今日摄入{total_calories}千卡，请给出适合的运动建议，帮助消耗多余卡路里。"
    
    headers = {
        'Authorization': f'Bearer {ALIYUN_API_KEY}',
        'Content-Type': 'application/json'
    }
    
    data = {
        'model': 'qwen-turbo',
        'input': {
            'messages': [
                {'role': 'user', 'content': prompt}
            ]
        }
    }
    
    try:
        response = requests.post(ALIYUN_API_URL, headers=headers, json=data)
        result = response.json()
        suggestion = result['output']['text'].strip()
        return clean_text(suggestion)
    except Exception as e:
        print(f"AI生成运动建议失败: {e}")
        return "建议进行30分钟的有氧运动，如散步或骑自行车。"

@app.route('/')
def index():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return redirect(url_for('diary'))

@app.route('/diary')
def diary():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']
    selected_date = parse_date(request.args.get('date', datetime.now().strftime('%Y-%m-%d')))
    prev_date = selected_date - timedelta(days=1)
    current_date = datetime.now().date()
    next_date = selected_date + timedelta(days=1) if selected_date < current_date else selected_date

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT id, food_name, weight, image_path, calories FROM food_records WHERE user_id = %s AND date = %s', (user_id, selected_date))
    records = cursor.fetchall()
    cursor.execute('SELECT total_calories, exercise_suggestion FROM daily_summaries WHERE user_id = %s AND date = %s', (user_id, selected_date))
    summary = cursor.fetchone()
    cursor.close()
    conn.close()

    return render_template('diary.html', selected_date=selected_date, current_date=datetime.now().date(), day_of_week=get_day_of_week(selected_date), prev_date=prev_date, next_date=next_date, records=records, summary=summary)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT id, password FROM users WHERE username = %s', (username,))
        user = cursor.fetchone()
        cursor.close()
        conn.close()
        
        if user and check_password_hash(user[1], password):
            session['user_id'] = user[0]
            return redirect(url_for('dashboard'))
        else:
            flash('用户名或密码错误')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('INSERT INTO users (username, password) VALUES (%s, %s)',
                         (username, generate_password_hash(password)))
            conn.commit()
            flash('注册成功，请登录')
            return redirect(url_for('login'))
        except pymysql.IntegrityError:
            flash('用户名已存在')
        finally:
            cursor.close()
            conn.close()
    
    return render_template('register.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    selected_date = parse_date(request.args.get('date', datetime.now().strftime('%Y-%m-%d')))
    prev_date = selected_date - timedelta(days=1)
    current_date = datetime.now().date()
    next_date = selected_date + timedelta(days=1) if selected_date < current_date else selected_date
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # 获取所选日期饮食记录
    cursor.execute('SELECT id, food_name, weight, image_path, calories FROM food_records WHERE user_id = %s AND date = %s', (user_id, selected_date))
    records = cursor.fetchall()
    
    # 获取所选日期总结
    cursor.execute('SELECT total_calories, exercise_suggestion FROM daily_summaries WHERE user_id = %s AND date = %s', (user_id, selected_date))
    summary = cursor.fetchone()
    
    cursor.close()
    conn.close()
    
    return render_template('dashboard.html', records=records, summary=summary, selected_date=selected_date, current_date=datetime.now().date(), day_of_week=get_day_of_week(selected_date), prev_date=prev_date, next_date=next_date)

@app.route('/add_food', methods=['GET', 'POST'])
def add_food():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    selected_date = parse_date(request.args.get('date', datetime.now().strftime('%Y-%m-%d')))
    prev_date = selected_date - timedelta(days=1)
    current_date = datetime.now().date()
    next_date = selected_date + timedelta(days=1) if selected_date < current_date else selected_date
    
    if request.method == 'POST':
        food_name = request.form['food_name']
        weight = float(request.form['weight'])
        file = request.files['image']
        
        image_path = None
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            image_path = os.path.join('uploads', filename).replace('\\', '/')
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        
        # 计算卡路里
        calories = calculate_calories_with_ai(food_name, weight)
        
        user_id = session['user_id']
        record_date = selected_date
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO food_records (user_id, food_name, weight, image_path, calories, date) VALUES (%s, %s, %s, %s, %s, %s)',
                     (user_id, food_name, weight, image_path, calories, record_date))
        conn.commit()
        cursor.close()
        conn.close()
        
        # 更新每日总结
        update_daily_summary(user_id, record_date)
        
        flash('食物记录添加成功')
        return redirect(url_for('dashboard', date=selected_date.strftime('%Y-%m-%d')))
    
    return render_template('add_food.html', selected_date=selected_date, current_date=datetime.now().date(), day_of_week=get_day_of_week(selected_date), prev_date=prev_date, next_date=next_date)

def update_daily_summary(user_id, date):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # 计算总卡路里
    cursor.execute('SELECT SUM(calories) FROM food_records WHERE user_id = %s AND date = %s', (user_id, date))
    total_calories = cursor.fetchone()[0] or 0
    
    # 生成运动建议
    exercise_suggestion = get_exercise_suggestion(total_calories)
    
    # 插入或更新每日总结
    cursor.execute('''
        INSERT INTO daily_summaries (user_id, date, total_calories, exercise_suggestion)
        VALUES (%s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE total_calories = %s, exercise_suggestion = %s
    ''', (user_id, date, total_calories, exercise_suggestion, total_calories, exercise_suggestion))
    
    conn.commit()
    cursor.close()
    conn.close()

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)