import pymysql
# 数据库连接配置
DB_CONFIG = {
    'host': '106.14.246.124',
    'port': 3306,
    'user': 'studyuser',
    'password': '123456',
    'database': 'food'
}

def create_tables():
    try:
        conn = pymysql.connect(**DB_CONFIG)
        cursor = conn.cursor()

        # 创建用户表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # 创建饮食记录表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS food_records (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                food_name VARCHAR(100) NOT NULL,
                weight FLOAT NOT NULL,
                image_path VARCHAR(255),
                calories FLOAT,
                date DATE NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')

        # 创建每日总结表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS daily_summaries (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                date DATE NOT NULL,
                total_calories FLOAT NOT NULL,
                exercise_suggestion TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id),
                UNIQUE KEY unique_user_date (user_id, date)
            )
        ''')

        conn.commit()
        print("✅ 数据库表创建成功！")
        cursor.close()
        conn.close()
    except Exception as e:
        print(f"❌ 数据库表创建失败: {e}")

if __name__ == "__main__":
    create_tables()