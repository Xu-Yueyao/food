# 饮食记录系统

这是一个基于Flask的Web应用，让用户记录每日饮食情况，接入AI计算卡路里并给出运动建议。

## 功能特性

- 用户注册和登录
- 记录食物种类、重量和图片
- AI计算每日摄入卡路里（使用阿里云百炼大模型）
- 生成个性化运动建议
- 响应式Web界面

## 技术栈

- 后端：Flask + Python
- 数据库：MySQL
- AI：阿里云百炼大模型
- 前端：HTML + Bootstrap

## 安装和运行

1. 安装依赖：
   ```
   pip install -r requirements.txt
   ```

2. 初始化数据库：
   ```
   python init_db.py
   ```

3. 配置阿里云API密钥：
   在 `app.py` 中替换 `ALIYUN_API_KEY` 为您的实际API密钥。

4. 运行应用：
   ```
   python app.py
   ```

5. 访问 http://localhost:5000

## 数据库配置

数据库连接信息已在代码中配置，请确保MySQL服务器运行并可访问。

## 注意事项

- 请将 `app.py` 中的 `ALIYUN_API_KEY` 替换为您的阿里云百炼API密钥。
- 确保上传文件夹 `static/uploads` 有写入权限。
- 生产环境请修改 `app.secret_key` 为安全的随机字符串。